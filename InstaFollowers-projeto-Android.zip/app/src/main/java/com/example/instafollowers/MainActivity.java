package com.example.instafollowers;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.*;

public class MainActivity extends Activity {
    private EditText username;
    private String cleanUsername() {
        String value = username.getText().toString().trim().replace("@", "");
        return value.replaceAll("[^A-Za-z0-9._]", "");
    }
    private void openInstagram(String suffix) {
        String user = cleanUsername();
        if (user.isEmpty()) {
            username.setError("Digite seu nome de usuário");
            return;
        }
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
            .hideSoftInputFromWindow(username.getWindowToken(), 0);
        String url = "https://www.instagram.com/" + user + "/" + suffix;
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        try { startActivity(intent); }
        catch (Exception e) {
            Toast.makeText(this, "Não foi possível abrir o Instagram.", Toast.LENGTH_LONG).show();
        }
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }
    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(207, 55, 130)));
        return b;
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        int bg = Color.rgb(16, 16, 20), panel = Color.rgb(34, 34, 42), muted = Color.rgb(180,180,190);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(24, 36, 24, 24);
        root.setBackgroundColor(bg);

        TextView title = text("◎  InstaFollowers", 27, Color.WHITE, true);
        root.addView(title);
        TextView subtitle = text("Seu perfil, seus seguidores.", 14, muted, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-2, -2);
        sp.topMargin = 8; sp.bottomMargin = 28; root.addView(subtitle, sp);

        TextView label = text("Nome de usuário do Instagram", 15, Color.WHITE, true);
        root.addView(label);
        username = new EditText(this);
        username.setSingleLine(true);
        username.setHint("@seu_usuario");
        username.setTextColor(Color.WHITE);
        username.setHintTextColor(muted);
        username.setPadding(16, 10, 16, 10);
        username.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(207,55,130)));
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, -2);
        ep.topMargin = 8; ep.bottomMargin = 20; root.addView(username, ep);

        LinearLayout stats = new LinearLayout(this);
        stats.setPadding(16, 22, 16, 22);
        stats.setBackgroundColor(panel);
        stats.setGravity(Gravity.CENTER);
        TextView followers = text("Seguidores\nConsulte no Instagram", 16, Color.WHITE, true);
        followers.setGravity(Gravity.CENTER);
        TextView following = text("Seguindo\nConsulte no Instagram", 16, Color.WHITE, true);
        following.setGravity(Gravity.CENTER);
        stats.addView(followers, new LinearLayout.LayoutParams(0, -2, 1));
        stats.addView(following, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(-1, -2);
        stp.bottomMargin = 22; root.addView(stats, stp);

        Button profile = button("Abrir meu perfil");
        root.addView(profile, new LinearLayout.LayoutParams(-1, -2));
        profile.setOnClickListener(v -> openInstagram(""));
        Button list = button("Ver lista de seguidores");
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = 10; root.addView(list, lp);
        list.setOnClickListener(v -> openInstagram("followers/"));

        TextView note = text("Por segurança, o app não pede sua senha. A contagem e a lista são consultadas dentro do Instagram; este app não acessa dados privados nem promete atualização automática.", 12, muted, false);
        note.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.topMargin = 26; root.addView(note, np);

        setContentView(root);
    }
}
