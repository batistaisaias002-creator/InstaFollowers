package com.example.instafollowers;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;

public class MainActivity extends Activity {
    private static final int PICK_FOLLOWERS = 101;
    private static final int PICK_FOLLOWING = 102;
    private EditText username;
    private TextView status, result;
    private Set<String> followers = new HashSet<>();
    private Set<String> following = new HashSet<>();
    private SharedPreferences prefs;
    private int bg = Color.rgb(16, 16, 20);
    private int panel = Color.rgb(34, 34, 42);
    private int muted = Color.rgb(180, 180, 190);
    private int accent = Color.rgb(207, 55, 130);

    private String cleanUsername() {
        String value = username.getText().toString().trim().replace("@", "");
        return value.replaceAll("[^A-Za-z0-9._]", "");
    }

    private void openInstagram(String suffix) {
        String user = cleanUsername();
        if (user.isEmpty()) {
            username.setError("Digite seu nome de usuário");
            return;
        }
        ((InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE))
            .hideSoftInputFromWindow(username.getWindowToken(), 0);
        Intent intent = new Intent(Intent.ACTION_VIEW,
            Uri.parse("https://www.instagram.com/" + user + "/" + suffix));
        try { startActivity(intent); }
        catch (Exception e) {
            Toast.makeText(this, "Não foi possível abrir o Instagram.", Toast.LENGTH_LONG).show();
        }
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent));
        return b;
    }

    private void addButton(LinearLayout root, String label, View.OnClickListener listener) {
        Button b = button(label);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2);
        p.topMargin = 9;
        root.addView(b, p);
        b.setOnClickListener(listener);
    }

    private void chooseJson(int requestCode) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/plain"});
        startActivityForResult(intent, requestCode);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        try {
            String content = readUri(data.getData());
            Set<String> names = parseInstagramJson(content);
            if (names.isEmpty()) {
                status.setText("Não encontrei nomes nesse arquivo. Confira se selecionou o JSON correto do Instagram.");
                return;
            }
            if (requestCode == PICK_FOLLOWERS) {
                followers = names;
                status.setText("Seguidores importados: " + followers.size());
            } else if (requestCode == PICK_FOLLOWING) {
                following = names;
                status.setText("Seguindo importados: " + following.size());
            }
            updateSummary();
        } catch (Exception e) {
            status.setText("Não consegui ler esse arquivo. Selecione o JSON original do Instagram.");
        }
    }

    private String readUri(Uri uri) throws Exception {
        InputStream in = getContentResolver().openInputStream(uri);
        if (in == null) throw new Exception("Arquivo indisponível");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int n;
        while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        in.close();
        return new String(out.toByteArray(), StandardCharsets.UTF_8);
    }

    private Set<String> parseInstagramJson(String content) throws Exception {
        Set<String> names = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        String trimmed = content.trim();
        if (trimmed.startsWith("{")) collectNames(new JSONObject(trimmed), names);
        else if (trimmed.startsWith("[")) collectNames(new JSONArray(trimmed), names);
        return names;
    }

    private void collectNames(Object node, Set<String> names) throws Exception {
        if (node instanceof JSONObject) {
            JSONObject obj = (JSONObject) node;
            JSONArray list = obj.optJSONArray("string_list_data");
            if (list != null) {
                for (int i = 0; i < list.length(); i++) {
                    JSONObject item = list.optJSONObject(i);
                    if (item != null) addName(names, item.optString("value", ""));
                }
            }
            JSONArray directArray = obj.optJSONArray("relationships_following");
            if (directArray != null) collectNames(directArray, names);
            java.util.Iterator<String> keys = obj.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                Object value = obj.opt(key);
                if (value instanceof JSONObject || value instanceof JSONArray) collectNames(value, names);
            }
        } else if (node instanceof JSONArray) {
            JSONArray arr = (JSONArray) node;
            for (int i = 0; i < arr.length(); i++) {
                Object value = arr.opt(i);
                if (value instanceof JSONObject || value instanceof JSONArray) collectNames(value, names);
            }
        }
    }

    private void addName(Set<String> names, String raw) {
        if (raw == null) return;
        String name = raw.trim().replaceFirst("^@", "");
        if (name.matches("[A-Za-z0-9._]{1,30}")) names.add(name);
    }

    private void updateSummary() {
        StringBuilder s = new StringBuilder();
        s.append("Seguidores importados: ").append(followers.size()).append("\n");
        s.append("Seguindo importados: ").append(following.size()).append("\n");
        s.append("Não seguem de volta: ").append(difference(following, followers).size());
        status.setText(s.toString());
    }

    private Set<String> difference(Set<String> a, Set<String> b) {
        Set<String> out = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        for (String value : a) {
            boolean found = false;
            for (String other : b) if (value.equalsIgnoreCase(other)) { found = true; break; }
            if (!found) out.add(value);
        }
        return out;
    }

    private void compareLists() {
        if (followers.isEmpty() || following.isEmpty()) {
            result.setText("Importe os dois arquivos JSON: seguidores e seguindo.");
            return;
        }
        Set<String> notFollowingBack = difference(following, followers);
        StringBuilder out = new StringBuilder();
        out.append("CONTAS QUE VOCÊ SEGUE E NÃO SEGUEM DE VOLTA\n");
        out.append("Total: ").append(notFollowingBack.size()).append("\n\n");
        int count = 0;
        for (String name : notFollowingBack) {
            out.append("@").append(name).append("\n");
            if (++count >= 150) {
                out.append("\n...lista limitada a 150 nomes nesta tela.");
                break;
            }
        }
        if (notFollowingBack.isEmpty()) out.append("Nenhuma conta encontrada nessa comparação.");
        result.setText(out.toString());
    }

    private void saveSnapshot() {
        if (followers.isEmpty()) {
            status.setText("Importe primeiro o arquivo de seguidores atual.");
            return;
        }
        JSONArray arr = new JSONArray();
        for (String name : followers) arr.put(name);
        prefs.edit().putString("previous_followers", arr.toString()).apply();
        status.setText("Histórico salvo neste celular: " + followers.size() + " seguidores.");
    }

    private void compareSnapshot() {
        String saved = prefs.getString("previous_followers", null);
        if (saved == null) {
            result.setText("Ainda não existe histórico. Importe seus seguidores e toque em Salvar histórico.");
            return;
        }
        if (followers.isEmpty()) {
            result.setText("Importe primeiro o arquivo atual de seguidores.");
            return;
        }
        try {
            JSONArray arr = new JSONArray(saved);
            Set<String> old = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
            for (int i = 0; i < arr.length(); i++) addName(old, arr.optString(i, ""));
            Set<String> lost = difference(old, followers);
            StringBuilder out = new StringBuilder();
            out.append("CONTAS QUE ESTAVAM NA LISTA ANTERIOR E NÃO ESTÃO NA ATUAL\n");
            out.append("Total: ").append(lost.size()).append("\n\n");
            for (String name : lost) out.append("@").append(name).append("\n");
            if (lost.isEmpty()) out.append("Nenhuma diferença encontrada.");
            out.append("\n\nObservação: isso compara dois arquivos exportados em datas diferentes; não prova o motivo da mudança.");
            result.setText(out.toString());
        } catch (Exception e) {
            result.setText("Não foi possível ler o histórico salvo.");
        }
    }

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("instafollowers", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22, 28, 22, 28);
        root.setBackgroundColor(bg);

        ScrollView scroll = new ScrollView(this);
        scroll.addView(root);

        TextView title = text("◎  InstaFollowers", 28, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title);
        TextView subtitle = text("Análise local dos seus dados do Instagram", 14, muted, false);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sub = new LinearLayout.LayoutParams(-1, -2);
        sub.topMargin = 7; sub.bottomMargin = 22;
        root.addView(subtitle, sub);

        root.addView(text("Nome de usuário do Instagram", 15, Color.WHITE, true));
        username = new EditText(this);
        username.setSingleLine(true);
        username.setHint("@seu_usuario");
        username.setTextColor(Color.WHITE);
        username.setHintTextColor(muted);
        username.setPadding(14, 10, 14, 10);
        username.setBackgroundTintList(android.content.res.ColorStateList.valueOf(accent));
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, -2);
        ep.topMargin = 7; ep.bottomMargin = 10;
        root.addView(username, ep);
        addButton(root, "Abrir meu perfil no Instagram", v -> openInstagram(""));

        TextView section = text("IMPORTAR DADOS OFICIAIS", 17, Color.WHITE, true);
        LinearLayout.LayoutParams secp = new LinearLayout.LayoutParams(-1, -2);
        secp.topMargin = 24; root.addView(section, secp);
        TextView help = text("No Instagram, solicite o download das suas informações e escolha o formato JSON. Depois selecione os arquivos de seguidores e seguindo aqui.", 13, muted, false);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.topMargin = 7; root.addView(help, hp);

        addButton(root, "Importar arquivo de SEGUIDORES", v -> chooseJson(PICK_FOLLOWERS));
        addButton(root, "Importar arquivo de SEGUINDO", v -> chooseJson(PICK_FOLLOWING));

        status = text("Nenhum arquivo importado ainda.", 14, Color.WHITE, false);
        status.setPadding(14, 14, 14, 14);
        status.setBackgroundColor(panel);
        LinearLayout.LayoutParams st = new LinearLayout.LayoutParams(-1, -2);
        st.topMargin = 16; root.addView(status, st);

        addButton(root, "Comparar: quem não segue de volta", v -> compareLists());
        addButton(root, "Salvar lista atual como histórico", v -> saveSnapshot());
        addButton(root, "Comparar com histórico anterior", v -> compareSnapshot());

        result = text("Os resultados aparecerão aqui.", 14, Color.WHITE, false);
        result.setPadding(14, 14, 14, 14);
        result.setBackgroundColor(panel);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(-1, -2);
        rp.topMargin = 16; rp.bottomMargin = 20;
        root.addView(result, rp);

        TextView privacy = text("Privacidade: os arquivos são lidos e comparados no próprio celular. O app não pede nem armazena sua senha do Instagram. Os resultados dependem dos arquivos exportados e da data em que foram gerados.", 12, muted, false);
        privacy.setGravity(Gravity.CENTER);
        root.addView(privacy);

        setContentView(scroll);
    }
}
